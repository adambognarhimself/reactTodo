import './WelcomePage.less'

export function WelcomePage(){

    return <div className={"WelcomePage"}>

        <p>Welcome</p>
        <p>Create or select a project to start</p>
        
    </div>
}